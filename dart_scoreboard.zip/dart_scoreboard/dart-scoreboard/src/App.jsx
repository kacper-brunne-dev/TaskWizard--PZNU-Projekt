import { useEffect, useMemo, useState } from "react";
import dartboard from "./assets/dartboard.png";
import "./app.css";

const GAME_MODES = [501, 401, 301, 201, 101];
const MIN_PLAYERS = 1;
const MAX_PLAYERS = 8;

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function shuffle(array) {
  const a = [...array];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function formatAvg(n) {
  return Number.isFinite(n) ? n.toFixed(2) : "0.00";
}

export default function App() {
  const [stage, setStage] = useState("setup"); // setup | game | finished

  /* ===== SETUP ===== */
  const [playerCount, setPlayerCount] = useState(2);
  const [mode, setMode] = useState(301);
  const [players, setPlayers] = useState([
    { id: crypto.randomUUID(), name: "" },
    { id: crypto.randomUUID(), name: "" },
  ]);
  const [randomOnce, setRandomOnce] = useState(false);

  /* ===== GAME ===== */
  const [scores, setScores] = useState([]);
  const [activeIdx, setActiveIdx] = useState(0);

  const [turnsTaken, setTurnsTaken] = useState([]);
  const [totalScored, setTotalScored] = useState([]);

  const [darts, setDarts] = useState([0, 0, 0]);
  const [dartIdx, setDartIdx] = useState(0);
  const [mult, setMult] = useState(1);

  const [history, setHistory] = useState([]);
  const [winnerId, setWinnerId] = useState(null);

  /* ===== EFFECTS ===== */
  useEffect(() => {
    setPlayers((prev) => {
      const next = [...prev];
      while (next.length < playerCount)
        next.push({ id: crypto.randomUUID(), name: "" });
      while (next.length > playerCount) next.pop();
      return next;
    });
  }, [playerCount]);

  const canStart = useMemo(
    () => players.every((p) => p.name.trim() !== ""),
    [players]
  );

  /* ===== SETUP ACTIONS ===== */
  function movePlayer(i, dir) {
    setPlayers((prev) => {
      const next = [...prev];
      const j = i + dir;
      if (j < 0 || j >= next.length) return prev;
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });
  }

  function randomizeOrderOnce() {
    setPlayers((prev) => shuffle(prev));
    setRandomOnce(true);
  }

  function startGame() {
    setStage("game");
    setScores(players.map(() => mode));
    setTurnsTaken(players.map(() => 0));
    setTotalScored(players.map(() => 0));
    setActiveIdx(0);
    setDarts([0, 0, 0]);
    setHistory([]);
    setWinnerId(null);
  }

  /* ===== GAME LOGIC ===== */
  function applyKey(n) {
    let value = 0;
    if (n === 25) {
      if (mult === 3) return;
      value = mult === 2 ? 50 : 25;
    } else {
      value = n * mult;
    }

    setDarts((prev) => {
      const next = [...prev];
      next[dartIdx] = value;
      return next;
    });

    setDartIdx((i) => (i < 2 ? i + 1 : i));
    setMult(1);
  }

  function undo() {
    setDarts((prev) => {
      const next = [...prev];
      next[dartIdx] = 0;
      return next;
    });
    setMult(1);
  }

  function submitTurn() {
    const sum = darts.reduce((a, b) => a + b, 0);
    const before = scores[activeIdx];
    const after = before - sum;

    const bust = after < 0;
    const win = after === 0;

    setHistory((h) => [
      `${players[activeIdx].name}: [${darts.join(", ")}] = ${sum} ${
        bust ? "→ BUST" : win ? "→ WIN" : `→ ${after}`
      }`,
      ...h,
    ]);

    setTurnsTaken((t) => {
      const next = [...t];
      next[activeIdx]++;
      return next;
    });

    if (!bust) {
      setScores((s) => {
        const next = [...s];
        next[activeIdx] = after;
        return next;
      });
      setTotalScored((t) => {
        const next = [...t];
        next[activeIdx] += sum;
        return next;
      });
    }

    setDarts([0, 0, 0]);
    setDartIdx(0);

    if (win) {
      setWinnerId(players[activeIdx].id);
      setStage("finished");
      return;
    }

    setActiveIdx((i) => (i + 1) % players.length);
  }

  const leaderboard = useMemo(
    () =>
      players
        .map((p, i) => ({ ...p, remaining: scores[i] }))
        .sort((a, b) => a.remaining - b.remaining),
    [players, scores]
  );

  /* ===== RENDER ===== */
  return (
    <div className="page">
      <header className="topbar">
        <div className="brand">Dart Scoreboard</div>
        <div className="pill">X01</div>
      </header>

      {/* ================= SETUP ================= */}
      {stage === "setup" && (
        <div className="card">
          <h2>Konfiguracja gry</h2>

          <div className="grid2">
            <label className="field">
              <span>Liczba graczy</span>
              <select
                value={playerCount}
                onChange={(e) =>
                  setPlayerCount(clamp(+e.target.value, 1, 8))
                }
              >
                {Array.from({ length: 8 }, (_, i) => i + 1).map((n) => (
                  <option key={n}>{n}</option>
                ))}
              </select>
            </label>

            <label className="field">
              <span>Tryb gry</span>
              <select value={mode} onChange={(e) => setMode(+e.target.value)}>
                {GAME_MODES.map((m) => (
                  <option key={m}>{m}</option>
                ))}
              </select>
            </label>
          </div>

          <div className="sectionTitle">Gracze</div>

          {players.map((p, i) => (
            <div key={p.id} className="playerRow">
              <div className="order">{i + 1}</div>
              <input
                value={p.name}
                placeholder={`Gracz ${i + 1}`}
                onChange={(e) =>
                  setPlayers((prev) => {
                    const next = [...prev];
                    next[i] = { ...next[i], name: e.target.value };
                    return next;
                  })
                }
              />
              <div className="rowBtns">
                <button
                  className="btn ghost"
                  disabled={randomOnce || i === 0}
                  onClick={() => movePlayer(i, -1)}
                >
                  ↑
                </button>
                <button
                  className="btn ghost"
                  disabled={randomOnce || i === players.length - 1}
                  onClick={() => movePlayer(i, 1)}
                >
                  ↓
                </button>
              </div>
            </div>
          ))}

          <div className="setupActions">
            <button
              className="btn secondary"
              disabled={randomOnce}
              onClick={randomizeOrderOnce}
            >
              Rzucaj losowo
            </button>
            <button
              className="btn primary"
              disabled={!canStart}
              onClick={startGame}
            >
              Start
            </button>
          </div>
        </div>
      )}

      {/* ================= GAME ================= */}
      {(stage === "game" || stage === "finished") && (
      <div className="layout3">
  {/* LEWA KOLUMNA: SCOREBOARD */}
  <div className="col leftCol">
    <div className="card">
      <div className="scoreboard">
        {players.map((p, i) => {
          const avg = totalScored[i] / Math.max(1, turnsTaken[i] || 1);
          return (
            <div
              key={p.id}
              className={`scoreRow ${i === activeIdx && stage === "game" ? "active" : ""}`}
            >
              <div>
                <div className="remaining">{scores[i]}</div>
                <div>{p.name}</div>
              </div>
              <div>
                <div>Ø {formatAvg(avg)}</div>
                <div>Tury: {turnsTaken[i]}</div>
              </div>
            </div>
          );
        })}
      </div>

      {stage === "finished" && (
        <div className="winBox">
          Zwycięzca:{" "}
          <strong>{players.find((p) => p.id === winnerId)?.name}</strong>
        </div>
      )}
    </div>
  </div>

  {/* ŚRODEK: PROWADZENIE + TURA */}
  <div className="col centerCol">
    <div className="card">
      <div className="sectionTitle">Prowadzenie</div>
      {leaderboard.map((p, i) => (
        <div key={p.id} className="leaderRow">
          <span>{i + 1}.</span>
          <span>{p.name}</span>
          <strong>{p.remaining}</strong>
        </div>
      ))}
    </div>

    {stage === "game" && (
      <div className="card">
        <div className="dartInputs">
          {["D1", "D2", "D3"].map((l, i) => (
            <input
              key={l}
              value={darts[i]}
              onFocus={() => setDartIdx(i)}
              onChange={(e) =>
                setDarts((prev) => {
                  const next = [...prev];
                  next[i] = clamp(+e.target.value || 0, 0, 180);
                  return next;
                })
              }
            />
          ))}
        </div>

        <div className="keys">
          {Array.from({ length: 20 }, (_, i) => i + 1).map((n) => (
            <button key={n} onClick={() => applyKey(n)}>
              {n}
            </button>
          ))}
          <button onClick={() => applyKey(25)}>25</button>
          <button onClick={() => applyKey(0)}>0</button>
        </div>

        <div className="modRow">
          <button
            className={`btn ${mult === 2 ? "mod on" : "mod"}`}
            onClick={() => setMult(mult === 2 ? 1 : 2)}
          >
            DOUBLE
          </button>
          <button
            className={`btn ${mult === 3 ? "mod on" : "mod"}`}
            onClick={() => setMult(mult === 3 ? 1 : 3)}
          >
            TRIPLE
          </button>
          <button className="btn danger" onClick={undo}>
            UNDO
          </button>
        </div>

        <button className="btn primary" onClick={submitTurn}>
          Zatwierdź turę
        </button>
      </div>
    )}
  </div>

  {/* PRAWA KOLUMNA: TARCZA */}
  <div className="col rightCol">
    <div className="card dartboardCard">
      <img src={dartboard} alt="Dartboard" className="dartboardImg" />
    </div>
  </div>
</div>

      )}
    </div>
  );
}
